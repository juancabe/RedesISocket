/*
** Fichero: common_TCP.h
** Autores:
** Juan Calzada Bernal DNI 70919688Q
** Hugo Chalard Collado DNI 70964149H
*/

#ifndef COMMON_TCP_H
#define COMMON_TCP_H

#include "common.h"

#define STEP_SIZE_TCP 4096

#endif