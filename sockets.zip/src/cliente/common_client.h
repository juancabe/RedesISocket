/*
** Fichero: common_client.h
** Autores:
** Juan Calzada Bernal DNI 70919688Q
** Hugo Chalard Collado DNI 70964149H
*/

#ifndef COMMON_CLIENT_H
#define COMMON_CLIENT_H

#include "../common.h"

#define HOSTNAME "localhost"

#endif